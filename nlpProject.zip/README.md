# nlpProject
If you can read this file, you've successfully cloned the git repository. 

If this is your first time using git take a look at this to familiarize yourself with it:
http://git-scm.com/book/en/v2/Getting-Started-Git-Basics 

For sharing source code between teammates working on ReviewSummarizer

IMPORTANT: 
Please don't commit data files to this repository. Github wants repositories < 1 GB. I suggest
doing a git clone in a michelson computer, save the downloaded data in a directory above this 
repository so that it doesn't get committed. 

There is a .gitignore file right now that ignores all class files so we don't waste extra space.
